﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using YourNamespace;

namespace DatabaseViewer
{
    public partial class MainWindow : Window
    {
        private const string connectionString = "Data Source=0_311_11;Initial Catalog=BeautyShop_ton;Integrated Security=True";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowTable(string tableName)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = $"SELECT * FROM {tableName}";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    DataGrid dataGrid = new DataGrid
                    {
                        AutoGenerateColumns = true,
                        ItemsSource = table.DefaultView // Using DefaultView to convert DataTable to IEnumerable
                    };

                    Window tableWindow = new Window
                    {
                        Title = tableName,
                        Content = dataGrid,
                        Width = 600,
                        Height = 400,
                        WindowStartupLocation = WindowStartupLocation.CenterScreen // Устанавливаем положение окна по центру экрана
                    };

                    tableWindow.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void OrdersButton_Click(object sender, RoutedEventArgs e)
        {
            ShowTable("Услуги");
        }

        private void UsersButton_Click(object sender, RoutedEventArgs e)
        {
            ShowTable("Записи");
        }

        private void ProductsButton_Click(object sender, RoutedEventArgs e)
        {
            ShowTable("Сотрудники");
        }

        private void OrderDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            ShowTable("Клиенты");
        }

        // Обработчик события для кнопки показа новостей и акций
        private void ShowNewsAndPromotions_Click(object sender, RoutedEventArgs e)
        {
            // Создание и отображение страницы с новостями и акциями
            NewsAndPromotionsPage newsAndPromotionsPage = new NewsAndPromotionsPage();
            this.Content = newsAndPromotionsPage;
        }

        // Обработчик события для кнопки "Выход"
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            // Закрываем текущее окно
            this.Close();
        }
        private void ContactsButton_Click(object sender, RoutedEventArgs e)
        {
            // Создание и отображение окна с контактной информацией
            ContactsPage contactsPage = new ContactsPage();
            contactsPage.ShowDialog();
        }
    }
}
