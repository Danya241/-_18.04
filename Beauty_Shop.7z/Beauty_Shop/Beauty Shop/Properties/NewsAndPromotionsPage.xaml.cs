﻿using DatabaseViewer;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace YourNamespace
{
    public partial class NewsAndPromotionsPage : Page
    {
        public NewsAndPromotionsPage()
        {
            InitializeComponent();
            LoadNews();
            LoadPromotions();
        }

        private void LoadNews()
        {
            ObservableCollection<string> news = new ObservableCollection<string>
            {
                "Новинка в нашем салоне красоты! Теперь мы предлагаем профессиональное наращивание ресниц. Получите пышные и длинные ресницы всего за несколько часов.",
                "Только на этой неделе! Получите скидку 20% на любую услугу в нашем салоне красоты. Забронируйте свой прием уже сегодня!"
            };

            newsListBox.ItemsSource = news;
        }

        private void LoadPromotions()
        {
            ObservableCollection<string> promotions = new ObservableCollection<string>
            {
                "Для новых клиентов салона красоты действует специальная акция! Получите скидку 30% на первый визит к нам. Наслаждайтесь профессиональными услугами по выгодной цене!"
            };

            promotionsListBox.ItemsSource = promotions;
        }

        // Обработчик события для кнопки "Назад"
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр главного окна
            MainWindow mainWindow = new MainWindow();
            // Закрываем текущее окно
            Window.GetWindow(this).Close();
            // Открываем главное окно
            mainWindow.Show();
        }
    }
}
