﻿using System.Windows;

namespace YourNamespace
{
    public partial class ContactsPage : Window
    {
        public ContactsPage()
        {
            InitializeComponent();
        }
    }
}
